/**
 * Main Transaction Class 
 *
 * @author  Akash Shah 
 * @version  1.7.0   
 * 
 *  Date Created: 03 / 14 / 2019
 */



// initializes the public class "Transaction" into effect. 

public class Transaction{
	
// defines the needed variables into a private class 

	private int _id;
	private String _buyer;
	private String _seller;
	private double _amount;
	private String _timeStamp;
	
	// defines the needed variables into a public class (so can called globally throughout all the classes from this project)

	public Transaction(int theId, String theBuyer, String theSeller, double theAmount, String theTimeStamp) {
        this._id = theId;
        this._buyer = theBuyer;
        this._seller = theSeller;
        this._amount = theAmount;
        this._timeStamp = theTimeStamp;
    }
	
	public Transaction( ) { }

	public int getId( ) {
		return _id;
	}
	
	public String getBuyer( ) {
		return _buyer;
	}
	
	public String getSeller( ) {
		return _seller;
	}
	
	public double getAmount( ) {
		return _amount;
	}

	public String getTimeStamp( ) {
		return _timeStamp;
	}

	
	// This Overrides the public toString method 
	@Override
    public String toString( ) {
        return String.format("ID: %d BUYER: %s SELLER: %s AMOUNT: $%.2f TIMESTAMP: %s",       		
            _id, _buyer, _seller, _amount, _timeStamp);
	}
}