/**
 * Main TransactionLogger Class - This class logs all the information for winners 
 *
 * @author  Akash Shah 
 * @version  1.7.0   
 * 
 *  Date Created: 03 / 14 / 2019
 */

// imports created and defined below 

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Observable;
import java.util.Observer;
public class TransactionLogger implements Observer{
    PrintWriter _log;
    
    public TransactionLogger(String fileName) 
        throws FileNotFoundException {
        _log = new PrintWriter(fileName); // prints file name
    }

    
  // overrides public void update
	@Override
	public void update(Observable obs, Object info) {
		_log.println(info);
		_log.flush();
	}
}