/**
 * Main Transaction Checker Class 
 *
 * @author  Akash Shah 
 * @version  1.7.0   
 * 
 *  Date Created: 03 / 14 / 2019
 */


// All the required imports imported below 

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Observable;
import java.util.Scanner;

// public class for TransactionChecker created here 

public class TransactionChecker extends Observable {
    Scanner _in;
    int id = 1001;
    String name = "";
    String buyer = "";
    double amount = 0.0;
    String time = "";
    
    public TransactionChecker(String fileName) 
        throws FileNotFoundException {
        _in = new Scanner(new File(fileName));
    }
    public void checkTransactions( ) {
        while(_in.hasNextLine( )) {
            String line = _in.nextLine( );
            String[ ] fields = line.split(",");
            name = fields[0];
            buyer = fields[1];
            amount =  Double.parseDouble(fields[2]);
            time = fields[3];

            Transaction t = new Transaction(id++, name, buyer, amount, time);
            
            if (amount > 50000 && name.equals("Eugene Eko")) {
            	setChanged();
            	notifyObservers(t);
            }
        }
        _in.close( );  // closes 
    }

}