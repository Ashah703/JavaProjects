/**
 * Test for Transcation Checker 
 *
 * @author  Akash Shah 
 * @version  1.7.0   
 * 
 *  Date Created: 03 / 14 / 2019
 */

import java.io.FileNotFoundException;

// Creates public class for Test Transaction Checker 

public class TestTransactionChecker {

	public static void main(String[] args) throws FileNotFoundException {
		TransactionChecker checker = new TransactionChecker("transactions.txt"); //opens transaction file 
		TransactionLogger logger = new TransactionLogger("log.txt"); // creates "log.txt" file as the output. 
		checker.addObserver(logger);
		checker.checkTransactions();
	}

}
